package src.main.java.com.github.hsmrs_gui.project.controller;

import java.awt.Color;
import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JLabel;


public class InteractiveMapControllerLabel implements MouseListener, MouseMotionListener{

	private static InteractiveMapControllerLabel instance;
	private ArrayList<JLabel> highlightedLabels;
	private ConsoleController consoleController;
	private boolean isDragging = false;
	
	private InteractiveMapControllerLabel(){
		consoleController = ConsoleController.getInstance();
		highlightedLabels = new ArrayList<JLabel>();
	}

	
	public static InteractiveMapControllerLabel getInstance(){
		if (instance == null){
			instance = new InteractiveMapControllerLabel();
		}
		
		return instance;
	}
	
	public void clearLabels(){
		for (JLabel lbl : highlightedLabels){
			lbl.setBackground(Color.white);
		}
		highlightedLabels.clear();
	}
	
	public void highlightLabel(JLabel target, boolean clearSelection){
		if (clearSelection) {
			for (JLabel lbl : highlightedLabels){
				lbl.setBackground(Color.white);
			}
			if (!highlightedLabels.contains(target)){
				target.setBackground(Color.yellow);
				highlightedLabels.clear();
				highlightedLabels.add(target);
			} else{
				highlightedLabels.clear();
			}		
		}else{
		
			target.setBackground(Color.yellow);
			highlightedLabels.add(target);
		}
		
		long timestamp = System.currentTimeMillis() / 1000;
		consoleController.addLog("System", timestamp, "Grid cell selected");
	}


	@Override
	public void mouseDragged(MouseEvent e) {
		if (!isDragging && !e.isControlDown()){
			clearLabels();
		}
		isDragging = true;
		//long timestamp = System.currentTimeMillis() / 1000;
		//consoleController.addLog("System", timestamp, "On Drag");
		Component comp = e.getComponent().getComponentAt(e.getPoint());
		if (comp instanceof JLabel){
			highlightLabel((JLabel)comp, false);
		}
	}


	@Override
	public void mouseMoved(MouseEvent e) {
		//long timestamp = System.currentTimeMillis() / 1000;
		//consoleController.addLog("System", timestamp, "On Move");		
	}


	@Override
	public void mouseClicked(MouseEvent e) {
		JLabel target = (JLabel)e.getComponent().getComponentAt(e.getPoint());
		highlightLabel(target, (e.isControlDown() ? false : true));
	}


	@Override
	public void mouseEntered(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void mouseExited(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void mousePressed(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void mouseReleased(MouseEvent arg0) {
		isDragging = false;
	}
}
