package src.main.java.com.github.hsmrs_gui.project.model;

import src.main.java.com.github.hsmrs_gui.project.ros.ImageListener;

public class Robot {

	private String name;
	private Task assignedTask;
	private String status;
	private String imageTopic;
	private ImageListener mImageListener;
		
	public Robot(){
		name = "No name given";
		assignedTask = new Task();
	}
	
	public Robot (String name){
		this.name = name;
		assignedTask = new Task();
	}
	
	public Robot (String name, Task task){
		this.name = name;
		assignedTask = task;
	}
	
	public Robot (String name, Task task, String imageTopic){
		this.name = name;
		assignedTask = task;
		this.imageTopic = imageTopic;
		mImageListener = new ImageListener(imageTopic);
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Task getAssignedTask() {
		return assignedTask;
	}
	
	public String getImageTopic(){
		return imageTopic;
	}

	public void setImageTopic(String imageTopic){
		this.imageTopic = imageTopic;
	}
	
	public void setAssignedTask(Task assignedTask) {
		this.assignedTask = assignedTask;
	}
	
	public void setImageListener(ImageListener il){
		mImageListener = il;
	}
	
	
}
