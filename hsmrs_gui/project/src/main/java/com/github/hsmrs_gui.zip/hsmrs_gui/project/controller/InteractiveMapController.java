package src.main.java.com.github.hsmrs_gui.project.controller;

import java.awt.Color;
import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;
import java.util.ArrayList;

import javax.swing.JButton;


public class InteractiveMapController implements MouseMotionListener{

	private static InteractiveMapController instance;
	private ArrayList<JButton> highlightedButtons;
	private ConsoleController consoleController;
	
	private InteractiveMapController(){
		consoleController = ConsoleController.getInstance();
		highlightedButtons = new ArrayList<JButton>();
	}

	
	public static InteractiveMapController getInstance(){
		if (instance == null){
			instance = new InteractiveMapController();
		}
		
		return instance;
	}
	
	public void highlightButton(JButton target, boolean clearSelection){
		if (clearSelection) {
			for (JButton btn : highlightedButtons){
				btn.setBackground(Color.white);
			}
			if (!highlightedButtons.contains(target)){
				target.setBackground(Color.yellow);
				highlightedButtons.clear();
				highlightedButtons.add(target);
			} else{
				highlightedButtons.clear();
			}		
		}else{
		
			target.setBackground(Color.yellow);
			highlightedButtons.add(target);
		}
		
		long timestamp = System.currentTimeMillis() / 1000;
		consoleController.addLog("System", timestamp, "Grid cell selected");
	}


	@Override
	public void mouseDragged(MouseEvent e) {
		//long timestamp = System.currentTimeMillis() / 1000;
		//consoleController.addLog("System", timestamp, "On Drag");
		Component comp = e.getComponent().getComponentAt(e.getPoint());
		if (comp instanceof JButton){
			highlightButton((JButton)comp, false);
		}
	}


	@Override
	public void mouseMoved(MouseEvent e) {
		//long timestamp = System.currentTimeMillis() / 1000;
		//consoleController.addLog("System", timestamp, "On Move");		
	}
}
