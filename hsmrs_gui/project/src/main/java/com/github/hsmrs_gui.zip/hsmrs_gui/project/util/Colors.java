package src.main.java.com.github.hsmrs_gui.project.util;

import java.awt.Color;

public class Colors {

	public static final Color selectionColor = new Color(204, 232, 252);
	public static final Color bannerColor = Color.decode("0XC0BCB6");
}
